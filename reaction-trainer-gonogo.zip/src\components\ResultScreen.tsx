import { useEffect, useMemo } from 'react';
import { Attempt } from '../models/Attempt';
import { StorageService } from '../services/StorageService';
import { createSessionResult, scoreLabel } from '../utils/results';

interface ResultScreenProps {
  attempts: Attempt[];
  onRestart: () => void;
  onHistory: () => void;
}

export function ResultScreen({ attempts, onRestart, onHistory }: ResultScreenProps) {
  const result = useMemo(() => createSessionResult(attempts), [attempts]);
  const label = scoreLabel(result.score);

  useEffect(() => {
    StorageService.add(result);
  }, [result]);

  return (
    <main className="screen">
      <p className="eyebrow">сессия завершена</p>
      <h2>Результаты</h2>

      <div className={`score ${label.className}`}>
        {label.text}: {result.score} / 100
      </div>

      <section className="stats-grid">
        <article>
          <strong>{result.averageReactionTime ? `${result.averageReactionTime} мс` : '--'}</strong>
          <span>Средняя реакция</span>
        </article>
        <article>
          <strong>{result.successes}</strong>
          <span>Успешных</span>
        </article>
        <article>
          <strong>{result.falseAlarms}</strong>
          <span>Ложных нажатий</span>
        </article>
        <article>
          <strong>{result.misses}</strong>
          <span>Пропусков</span>
        </article>
        <article>
          <strong>{result.earlyPresses}</strong>
          <span>Ранних нажатий</span>
        </article>
        <article>
          <strong>{result.totalAttempts}</strong>
          <span>Всего попыток</span>
        </article>
      </section>

      <div className="actions">
        <button className="button primary" onClick={onRestart}>
          Повторить
        </button>
        <button className="button ghost" onClick={onHistory}>
          История
        </button>
      </div>
    </main>
  );
}
