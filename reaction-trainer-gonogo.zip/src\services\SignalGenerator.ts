import { Signal, SignalType } from '../models/Signal';

export class SignalGenerator {
  constructor(
    private readonly goProbability = 0.7,
    private readonly minDelayMs = 800,
    private readonly maxDelayMs = 2500
  ) {}

  nextSignal(): Signal {
    return new Signal(Math.random() < this.goProbability ? SignalType.Go : SignalType.NoGo);
  }

  nextDelay(): number {
    return Math.floor(Math.random() * (this.maxDelayMs - this.minDelayMs) + this.minDelayMs);
  }
}
