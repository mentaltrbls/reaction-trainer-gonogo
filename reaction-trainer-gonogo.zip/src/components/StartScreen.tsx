import { ATTEMPT_STEP, MAX_ATTEMPTS, MIN_ATTEMPTS } from '../config';

interface StartScreenProps {
  attemptCount: number;
  onAttemptCountChange: (attemptCount: number) => void;
  onStart: () => void;
  onHistory: () => void;
}

function GoCircle() {
  return (
    <svg width="28" height="28" viewBox="0 0 56 56" fill="none" aria-hidden="true">
      <circle cx="28" cy="28" r="24" fill="rgba(0,229,122,0.15)" stroke="#00e57a" strokeWidth="2.5" />
      <polygon points="22,18 42,28 22,38" fill="#00e57a" />
    </svg>
  );
}

function NoGoCircle() {
  return (
    <svg width="28" height="28" viewBox="0 0 56 56" fill="none" aria-hidden="true">
      <circle cx="28" cy="28" r="24" fill="rgba(255,45,85,0.15)" stroke="#ff2d55" strokeWidth="2.5" />
      <rect x="18" y="25.5" width="20" height="5" rx="2.5" fill="#ff2d55" />
    </svg>
  );
}

export function StartScreen({ attemptCount, onAttemptCountChange, onStart, onHistory }: StartScreenProps) {
  const decreaseAttempts = () => {
    onAttemptCountChange(Math.max(MIN_ATTEMPTS, attemptCount - ATTEMPT_STEP));
  };

  const increaseAttempts = () => {
    onAttemptCountChange(Math.min(MAX_ATTEMPTS, attemptCount + ATTEMPT_STEP));
  };

  return (
    <main className="screen start-screen">
      <button className="button ghost top-right" onClick={onHistory}>
        История
      </button>

      <div className="start-logo">reaction trainer · v2.0</div>
      <h1 className="start-title">
        <span className="go-text">Go</span>
        <span className="title-separator"> / </span>
        <span className="nogo-text">No-Go</span>
      </h1>
      <p className="start-subtitle">Тест на скорость и точность реакции</p>

      <section className="rules-card">
        <div className="rule">
          <div className="rule-icon go"><GoCircle /></div>
          <div className="rule-text">
            <strong>Зелёный сигнал</strong> — нажмите пробел как можно быстрее
          </div>
        </div>
        <div className="rule">
          <div className="rule-icon nogo"><NoGoCircle /></div>
          <div className="rule-text">
            <strong>Красный сигнал</strong> — не нажимайте ничего
          </div>
        </div>
        <div className="rule">
          <div className="rule-icon space">SPC</div>
          <div className="rule-text">
            Нажатие до сигнала считается <strong>преждевременным</strong>
          </div>
        </div>
      </section>

      <section className="attempt-settings start-attempts" aria-label="Количество попыток">
        <div className="settings-title">
          <span>Попыток</span>
          <strong>{attemptCount}</strong>
        </div>
        <div className="stepper">
          <button className="button ghost step-button" onClick={decreaseAttempts} disabled={attemptCount <= MIN_ATTEMPTS}>
            -
          </button>
          <input
            type="range"
            min={MIN_ATTEMPTS}
            max={MAX_ATTEMPTS}
            step={ATTEMPT_STEP}
            value={attemptCount}
            onChange={(event) => onAttemptCountChange(Number(event.target.value))}
            aria-label="Количество попыток"
          />
          <button className="button ghost step-button" onClick={increaseAttempts} disabled={attemptCount >= MAX_ATTEMPTS}>
            +
          </button>
        </div>
      </section>

      <button className="button primary" onClick={onStart}>
        Начать сессию →
      </button>
      <p className="note">{attemptCount} попыток · управление клавишей Space</p>
    </main>
  );
}
