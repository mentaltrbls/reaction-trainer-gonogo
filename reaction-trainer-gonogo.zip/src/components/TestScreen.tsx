import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  GO_PROBABILITY,
  MAX_SIGNAL_DELAY_MS,
  MIN_SIGNAL_DELAY_MS,
  NEXT_ATTEMPT_DELAY_MS,
  SIGNAL_DURATION_MS
} from '../config';
import { Attempt, AttemptOutcome } from '../models/Attempt';
import { Signal, SignalType } from '../models/Signal';
import { SignalGenerator } from '../services/SignalGenerator';
import { SoundService } from '../services/SoundService';
import { StatisticsCalculator } from '../services/StatisticsCalculator';

type TestPhase = 'countdown' | 'waiting' | 'signal' | 'feedback';

interface TestScreenProps {
  totalAttempts: number;
  onDone: (attempts: Attempt[]) => void;
}

function GoCircle() {
  return (
    <svg width="56" height="56" viewBox="0 0 56 56" fill="none" aria-hidden="true">
      <circle cx="28" cy="28" r="24" fill="rgba(0,229,122,0.15)" stroke="#00e57a" strokeWidth="2.5" />
      <polygon points="22,18 42,28 22,38" fill="#00e57a" />
    </svg>
  );
}

function NoGoCircle() {
  return (
    <svg width="56" height="56" viewBox="0 0 56 56" fill="none" aria-hidden="true">
      <circle cx="28" cy="28" r="24" fill="rgba(255,45,85,0.15)" stroke="#ff2d55" strokeWidth="2.5" />
      <rect x="18" y="25.5" width="20" height="5" rx="2.5" fill="#ff2d55" />
    </svg>
  );
}

function IdleDot() {
  return (
    <svg width="56" height="56" viewBox="0 0 56 56" fill="none" aria-hidden="true">
      <circle cx="28" cy="28" r="8" fill="rgba(255,255,255,0.12)" />
    </svg>
  );
}

function outcomeDotClass(outcome: AttemptOutcome | 'pending') {
  if (outcome === AttemptOutcome.Success || outcome === AttemptOutcome.NoGoCorrect) {
    return 'success';
  }

  if (outcome === AttemptOutcome.FalseAlarm) {
    return 'false-alarm';
  }

  if (outcome === AttemptOutcome.Early) {
    return 'early';
  }

  if (outcome === AttemptOutcome.Miss) {
    return 'miss';
  }

  return 'pending';
}

export function TestScreen({ totalAttempts, onDone }: TestScreenProps) {
  const generator = useMemo(
    () => new SignalGenerator(GO_PROBABILITY, MIN_SIGNAL_DELAY_MS, MAX_SIGNAL_DELAY_MS),
    []
  );

  const [phase, setPhase] = useState<TestPhase>('countdown');
  const [countdown, setCountdown] = useState(3);
  const [signal, setSignal] = useState<Signal | null>(null);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [message, setMessage] = useState('Приготовьтесь');
  const [feedback, setFeedback] = useState<AttemptOutcome | null>(null);

  const phaseRef = useRef<TestPhase>('countdown');
  const signalRef = useRef<Signal | null>(null);
  const attemptsRef = useRef<Attempt[]>([]);
  const timerRef = useRef<number | null>(null);

  const setPhaseSync = (nextPhase: TestPhase) => {
    phaseRef.current = nextPhase;
    setPhase(nextPhase);
  };

  const setSignalSync = (nextSignal: Signal | null) => {
    signalRef.current = nextSignal;
    setSignal(nextSignal);
  };

  const clearTimer = () => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const addAttempt = useCallback((attempt: Attempt) => {
    attemptsRef.current = [...attemptsRef.current, attempt];
    setAttempts(attemptsRef.current);
  }, []);

  const showFeedback = (outcome: AttemptOutcome, nextMessage: string) => {
    setFeedback(outcome);
    setMessage(nextMessage);
    SoundService.play(
      outcome === AttemptOutcome.Success || outcome === AttemptOutcome.NoGoCorrect ? 'success' : 'error'
    );
  };

  const finishAttemptLater = useCallback((startNextAttempt: () => void) => {
    setPhaseSync('feedback');
    timerRef.current = window.setTimeout(startNextAttempt, NEXT_ATTEMPT_DELAY_MS);
  }, []);

  const startNextAttempt = useCallback(() => {
    if (attemptsRef.current.length >= totalAttempts) {
      SoundService.play('finish');
      onDone(attemptsRef.current);
      return;
    }

    setPhaseSync('waiting');
    setSignalSync(null);
    setFeedback(null);
    setMessage('Ожидайте сигнал');

    timerRef.current = window.setTimeout(() => {
      const nextSignal = generator.nextSignal();
      setSignalSync(nextSignal);
      setPhaseSync('signal');
      setMessage(nextSignal.isGo ? 'Нажмите пробел' : 'Не нажимайте');
      SoundService.play(nextSignal.isGo ? 'go' : 'nogo');

      timerRef.current = window.setTimeout(() => {
        if (phaseRef.current !== 'signal') {
          return;
        }

        if (signalRef.current?.type === SignalType.Go) {
          addAttempt(new Attempt(SignalType.Go, AttemptOutcome.Miss));
          showFeedback(AttemptOutcome.Miss, 'Пропуск');
        } else {
          addAttempt(new Attempt(SignalType.NoGo, AttemptOutcome.NoGoCorrect));
          showFeedback(AttemptOutcome.NoGoCorrect, 'Верно');
        }

        finishAttemptLater(startNextAttempt);
      }, SIGNAL_DURATION_MS);
    }, generator.nextDelay());
  }, [addAttempt, finishAttemptLater, generator, onDone, totalAttempts]);

  useEffect(() => {
    const countdownTimer = window.setInterval(() => {
      setCountdown((current) => {
        SoundService.play('countdown');

        if (current <= 1) {
          window.clearInterval(countdownTimer);
          attemptsRef.current = [];
          setAttempts([]);
          startNextAttempt();
          return 0;
        }

        return current - 1;
      });
    }, 800);

    return () => {
      window.clearInterval(countdownTimer);
      clearTimer();
    };
  }, [startNextAttempt]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.code !== 'Space' || event.repeat) {
        return;
      }

      event.preventDefault();

      if (phaseRef.current === 'waiting') {
        clearTimer();
        addAttempt(new Attempt(null, AttemptOutcome.Early));
        showFeedback(AttemptOutcome.Early, 'Слишком рано');
        finishAttemptLater(startNextAttempt);
        return;
      }

      if (phaseRef.current !== 'signal') {
        return;
      }

      clearTimer();

      if (signalRef.current?.type === SignalType.Go) {
        const reactionTime = Date.now() - signalRef.current.shownAt;
        addAttempt(new Attempt(SignalType.Go, AttemptOutcome.Success, reactionTime));
        showFeedback(AttemptOutcome.Success, `${reactionTime} мс`);
      } else {
        addAttempt(new Attempt(SignalType.NoGo, AttemptOutcome.FalseAlarm));
        showFeedback(AttemptOutcome.FalseAlarm, 'Ложное нажатие');
      }

      finishAttemptLater(startNextAttempt);
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [addAttempt, finishAttemptLater, startNextAttempt]);

  const progress = (attempts.length / totalAttempts) * 100;
  const averageReactionTime = StatisticsCalculator.averageReactionTime(attempts);
  let signalClass = phase === 'waiting' ? 'waiting' : 'idle';

  if (phase === 'signal') {
    signalClass = signal?.type === SignalType.Go ? 'go-signal' : 'nogo-signal';
  }

  if (phase === 'feedback') {
    signalClass =
      feedback === AttemptOutcome.Success || feedback === AttemptOutcome.NoGoCorrect ? 'success-anim' : 'shake-anim';
  }

  const feedbackClass =
    feedback === AttemptOutcome.Success || feedback === AttemptOutcome.NoGoCorrect ? 'feedback-good' : 'feedback-bad';
  const signalContent =
    phase === 'signal' ? (
      signal?.type === SignalType.Go ? (
        <GoCircle />
      ) : (
        <NoGoCircle />
      )
    ) : (
      <IdleDot />
    );
  const dotOutcomes = Array.from({ length: totalAttempts }, (_, index) => attempts[index]?.outcome ?? 'pending');
  const flashClass = phase === 'feedback' ? feedbackClass : '';

  return (
    <main className={`screen test-screen ${flashClass}`}>
      {phase === 'countdown' && (
        <div className="countdown">
          <strong>{countdown}</strong>
          <span>Приготовьтесь</span>
        </div>
      )}

      <header className="test-header">
          <span className="attempt-counter">
          Попытка {Math.min(attempts.length + 1, totalAttempts)} / {totalAttempts}
        </span>
        <div className="progress progress-bar">
          <div style={{ width: `${progress}%` }} />
        </div>
        <span>{averageReactionTime ? `${averageReactionTime} мс` : '-- мс'}</span>
      </header>

      <section className="signal-stage">
        <div className={`signal-ring ${signalClass}`}>
          <div className="signal-inner">
            <div className="signal-shape">{signalContent}</div>
            {phase === 'signal' && (
              <div className="signal-label" style={{ color: signal?.isGo ? 'var(--go)' : 'var(--nogo)' }}>
                {signal?.type}
              </div>
            )}
          </div>
        </div>
        <p className={`status-text ${phase === 'waiting' ? 'blink' : ''} ${phase === 'feedback' ? feedbackClass : ''}`}>
          {message}
        </p>
      </section>

      <div className="mini-log">
        {dotOutcomes.map((outcome, index) => (
          <div className={`log-dot ${outcomeDotClass(outcome)}`} key={index} />
        ))}
      </div>

      <footer className="test-footer">
        <div className="mini-stat">
          <strong>{StatisticsCalculator.successes(attempts)}</strong>
          <span>Успешных</span>
        </div>
        <div className="mini-stat">
          <strong>{StatisticsCalculator.falseAlarms(attempts)}</strong>
          <span>Ложных</span>
        </div>
        <div className="mini-stat">
          <strong>{StatisticsCalculator.misses(attempts)}</strong>
          <span>Пропусков</span>
        </div>
      </footer>
    </main>
  );
}
