import { useEffect, useState } from 'react';
import { SessionResult } from '../models/Session';
import { StorageService } from '../services/StorageService';
import { formatDate, scoreLabel } from '../utils/results';

interface HistoryScreenProps {
  onBack: () => void;
}

function ArrowLeftIcon() {
  return (
    <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M19 12H5" />
      <path d="m12 19-7-7 7-7" />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M3 6h18" />
      <path d="M8 6V4h8v2" />
      <path d="M6 6l1 15h10l1-15" />
      <path d="M10 11v6" />
      <path d="M14 11v6" />
    </svg>
  );
}

function HistoryIcon() {
  return (
    <svg className="title-icon" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M3 12a9 9 0 1 0 3-6.7" />
      <path d="M3 4v5h5" />
      <path d="M12 7v5l3 2" />
    </svg>
  );
}

export function HistoryScreen({ onBack }: HistoryScreenProps) {
  const [sessions, setSessions] = useState<SessionResult[]>([]);

  useEffect(() => {
    setSessions(StorageService.load());
  }, []);

  const clearHistory = () => {
    StorageService.clear();
    setSessions([]);
  };

  return (
    <main className="screen history-screen">
      <button className="button ghost icon-label top-left" onClick={onBack}>
        <ArrowLeftIcon />
        <span>Назад</span>
      </button>

      {sessions.length > 0 && (
        <button className="button ghost icon-label danger top-right" onClick={clearHistory}>
          <TrashIcon />
          <span>Очистить</span>
        </button>
      )}

      <div className="screen-meta">Результаты прошлых сессий</div>
      <h2 className="screen-title with-title-icon">
        <HistoryIcon />
        <span>История</span>
      </h2>

      <section className="history-list">
        {sessions.length === 0 && <p className="empty">Нет сохранённых сессий</p>}

        {sessions.map((session, index) => {
          const label = scoreLabel(session.score);

          return (
            <article className="history-row" key={session.id}>
              <span>#{index + 1}</span>
              <time>{formatDate(session.createdAt)}</time>
              <b>{session.averageReactionTime ? `${session.averageReactionTime} мс` : '--'}</b>
              <small>{session.successes} успешных</small>
              <small>{session.falseAlarms} ложных</small>
              <strong className={label.className}>{session.score}</strong>
            </article>
          );
        })}
      </section>
    </main>
  );
}
