import { useCallback, useRef, useState } from 'react';
import { HistoryScreen } from './components/HistoryScreen';
import { ResultScreen } from './components/ResultScreen';
import { StartScreen } from './components/StartScreen';
import { TestScreen } from './components/TestScreen';
import { DEFAULT_ATTEMPTS } from './config';
import { Attempt } from './models/Attempt';

type Screen = 'start' | 'test' | 'result' | 'history';

export function App() {
  const [screen, setScreen] = useState<Screen>('start');
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [attemptCount, setAttemptCount] = useState(DEFAULT_ATTEMPTS);
  const testKey = useRef(0);

  const navigate = useCallback((nextScreen: Screen) => {
    setScreen((currentScreen) => (currentScreen === nextScreen ? currentScreen : nextScreen));
  }, []);

  const startTest = useCallback(() => {
    testKey.current += 1;
    navigate('test');
  }, [navigate]);

  const finishTest = useCallback((finishedAttempts: Attempt[]) => {
    setAttempts(finishedAttempts);
    navigate('result');
  }, [navigate]);

  return (
    <>
      <div className={`animated-bg bg-${screen}`} aria-hidden="true">
        <span className="bg-ribbon ribbon-a" />
        <span className="bg-ribbon ribbon-b" />
        <span className="bg-beam beam-a" />
        <span className="bg-beam beam-b" />
        <span className="bg-beam beam-c" />
        <span className="bg-circuit circuit-a" />
        <span className="bg-circuit circuit-b" />
        <span className="bg-circuit circuit-c" />
        <span className="bg-ring ring-a" />
        <span className="bg-ring ring-b" />
        <span className="bg-sweep" />
      </div>
      <div className="scanline" />
      <div className="screen-transition">
        {screen === 'start' && (
          <StartScreen
            attemptCount={attemptCount}
            onAttemptCountChange={setAttemptCount}
            onStart={startTest}
            onHistory={() => navigate('history')}
          />
        )}
        {screen === 'test' && <TestScreen key={testKey.current} totalAttempts={attemptCount} onDone={finishTest} />}
        {screen === 'result' && (
          <ResultScreen attempts={attempts} onRestart={startTest} onHistory={() => navigate('history')} />
        )}
        {screen === 'history' && <HistoryScreen onBack={() => navigate('start')} />}
      </div>
    </>
  );
}
