type SoundName = 'countdown' | 'go' | 'nogo' | 'success' | 'error' | 'finish';

const SOUND_PRESETS: Record<SoundName, { frequency: number; duration: number; type: OscillatorType; gain: number }> = {
  countdown: { frequency: 560, duration: 0.08, type: 'sine', gain: 0.05 },
  go: { frequency: 760, duration: 0.12, type: 'triangle', gain: 0.07 },
  nogo: { frequency: 210, duration: 0.16, type: 'sawtooth', gain: 0.045 },
  success: { frequency: 920, duration: 0.1, type: 'sine', gain: 0.07 },
  error: { frequency: 150, duration: 0.18, type: 'square', gain: 0.04 },
  finish: { frequency: 660, duration: 0.16, type: 'triangle', gain: 0.06 }
};

export class SoundService {
  private static context: AudioContext | null = null;

  static play(name: SoundName) {
    const audioWindow = window as Window & typeof globalThis & { webkitAudioContext?: typeof AudioContext };
    const AudioContextClass = audioWindow.AudioContext ?? audioWindow.webkitAudioContext;

    if (!AudioContextClass) {
      return;
    }

    if (!this.context) {
      this.context = new AudioContextClass();
    }

    if (this.context.state === 'suspended') {
      void this.context.resume();
    }

    const preset = SOUND_PRESETS[name];
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();

    oscillator.type = preset.type;
    oscillator.frequency.setValueAtTime(preset.frequency, now);
    oscillator.connect(gain);
    gain.connect(this.context.destination);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(preset.gain, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + preset.duration);
    oscillator.start(now);
    oscillator.stop(now + preset.duration + 0.02);
  }
}
