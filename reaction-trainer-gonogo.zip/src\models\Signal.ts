export enum SignalType {
  Go = 'GO',
  NoGo = 'NOGO'
}

export class Signal {
  constructor(
    public readonly type: SignalType,
    public readonly shownAt: number = Date.now()
  ) {}

  get isGo(): boolean {
    return this.type === SignalType.Go;
  }
}
