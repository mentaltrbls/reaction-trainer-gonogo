import { useEffect, useState } from 'react';
import { SessionResult } from '../models/Session';
import { StorageService } from '../services/StorageService';
import { formatDate, scoreLabel } from '../utils/results';

interface HistoryScreenProps {
  onBack: () => void;
}

export function HistoryScreen({ onBack }: HistoryScreenProps) {
  const [sessions, setSessions] = useState<SessionResult[]>([]);

  useEffect(() => {
    setSessions(StorageService.load());
  }, []);

  const clearHistory = () => {
    StorageService.clear();
    setSessions([]);
  };

  return (
    <main className="screen history-screen">
      <button className="button ghost top-left" onClick={onBack}>
        Назад
      </button>

      {sessions.length > 0 && (
        <button className="button ghost top-right" onClick={clearHistory}>
          Очистить
        </button>
      )}

      <h2>История</h2>

      <section className="history-list">
        {sessions.length === 0 && <p className="empty">Сохранённых сессий пока нет</p>}

        {sessions.map((session, index) => {
          const label = scoreLabel(session.score);

          return (
            <article className="history-row" key={session.id}>
              <span>#{index + 1}</span>
              <time>{formatDate(session.createdAt)}</time>
              <b>{session.averageReactionTime ? `${session.averageReactionTime} мс` : '--'}</b>
              <small>{session.successes} успешных</small>
              <small>{session.falseAlarms} ложных</small>
              <strong className={label.className}>{session.score}</strong>
            </article>
          );
        })}
      </section>
    </main>
  );
}
