import { Attempt } from '../models/Attempt';
import { SessionResult } from '../models/Session';
import { StatisticsCalculator } from '../services/StatisticsCalculator';

export function createSessionResult(attempts: Attempt[]): SessionResult {
  return {
    id: crypto.randomUUID(),
    createdAt: Date.now(),
    averageReactionTime: StatisticsCalculator.averageReactionTime(attempts),
    falseAlarms: StatisticsCalculator.falseAlarms(attempts),
    misses: StatisticsCalculator.misses(attempts),
    successes: StatisticsCalculator.successes(attempts),
    earlyPresses: StatisticsCalculator.earlyPresses(attempts),
    totalAttempts: attempts.length,
    score: StatisticsCalculator.score(attempts)
  };
}

export function scoreLabel(score: number): { text: string; className: string } {
  if (score >= 80) {
    return { text: 'Отлично', className: 'good' };
  }

  if (score >= 55) {
    return { text: 'Хорошо', className: 'middle' };
  }

  return { text: 'Нужна практика', className: 'bad' };
}

export function formatDate(timestamp: number): string {
  return new Date(timestamp).toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}
