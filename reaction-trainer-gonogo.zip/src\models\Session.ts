export interface SessionResult {
  id: string;
  createdAt: number;
  averageReactionTime: number | null;
  falseAlarms: number;
  misses: number;
  successes: number;
  earlyPresses: number;
  totalAttempts: number;
  score: number;
}
