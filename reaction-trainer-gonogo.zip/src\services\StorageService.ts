import { SessionResult } from '../models/Session';

const STORAGE_KEY = 'gonogo_sessions_ts';

export class StorageService {
  static load(): SessionResult[] {
    try {
      const sessions = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]') as SessionResult[];
      return sessions.filter((session, index, all) => (
        all.findIndex((item) => item.id === session.id) === index
      ));
    } catch {
      return [];
    }
  }

  static add(session: SessionResult): void {
    const sessions = this.load();
    const exists = sessions.some((savedSession) => savedSession.id === session.id);

    if (exists) {
      return;
    }

    const nextSessions = [session, ...sessions].slice(0, 50);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(nextSessions));
  }

  static clear(): void {
    localStorage.removeItem(STORAGE_KEY);
  }
}
