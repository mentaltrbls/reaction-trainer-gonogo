import { Attempt, AttemptOutcome } from '../models/Attempt';

export class StatisticsCalculator {
  static averageReactionTime(attempts: Attempt[]): number | null {
    const successful = attempts.filter(
      (attempt) => attempt.outcome === AttemptOutcome.Success && attempt.reactionTime !== null
    );

    if (successful.length === 0) {
      return null;
    }

    const total = successful.reduce((sum, attempt) => sum + (attempt.reactionTime ?? 0), 0);
    return Math.round(total / successful.length);
  }

  static countByOutcome(attempts: Attempt[], outcome: AttemptOutcome): number {
    return attempts.filter((attempt) => attempt.outcome === outcome).length;
  }

  static falseAlarms(attempts: Attempt[]): number {
    return this.countByOutcome(attempts, AttemptOutcome.FalseAlarm);
  }

  static misses(attempts: Attempt[]): number {
    return this.countByOutcome(attempts, AttemptOutcome.Miss);
  }

  static successes(attempts: Attempt[]): number {
    return this.countByOutcome(attempts, AttemptOutcome.Success);
  }

  static earlyPresses(attempts: Attempt[]): number {
    return this.countByOutcome(attempts, AttemptOutcome.Early);
  }

  static score(attempts: Attempt[]): number {
    if (attempts.length === 0) {
      return 0;
    }

    const correctNoGo = this.countByOutcome(attempts, AttemptOutcome.NoGoCorrect);
    const correct = this.successes(attempts) + correctNoGo;
    const errors = this.falseAlarms(attempts) + this.misses(attempts) + this.earlyPresses(attempts);
    return Math.max(0, Math.round((correct / attempts.length) * 100 - errors * 3));
  }
}
