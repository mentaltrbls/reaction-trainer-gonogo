import { SignalType } from './Signal';

export enum AttemptOutcome {
  Success = 'success',
  Miss = 'miss',
  FalseAlarm = 'false-alarm',
  Early = 'early',
  NoGoCorrect = 'nogo-correct'
}

export class Attempt {
  constructor(
    public readonly signal: SignalType | null,
    public readonly outcome: AttemptOutcome,
    public readonly reactionTime: number | null = null
  ) {}
}
