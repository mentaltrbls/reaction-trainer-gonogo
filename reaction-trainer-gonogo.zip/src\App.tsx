import { useRef, useState } from 'react';
import { HistoryScreen } from './components/HistoryScreen';
import { ResultScreen } from './components/ResultScreen';
import { StartScreen } from './components/StartScreen';
import { TestScreen } from './components/TestScreen';
import { Attempt } from './models/Attempt';

type Screen = 'start' | 'test' | 'result' | 'history';

export function App() {
  const [screen, setScreen] = useState<Screen>('start');
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const testKey = useRef(0);

  const startTest = () => {
    testKey.current += 1;
    setScreen('test');
  };

  const finishTest = (finishedAttempts: Attempt[]) => {
    setAttempts(finishedAttempts);
    setScreen('result');
  };

  return (
    <>
      {screen === 'start' && <StartScreen onStart={startTest} onHistory={() => setScreen('history')} />}
      {screen === 'test' && <TestScreen key={testKey.current} onDone={finishTest} />}
      {screen === 'result' && (
        <ResultScreen attempts={attempts} onRestart={startTest} onHistory={() => setScreen('history')} />
      )}
      {screen === 'history' && <HistoryScreen onBack={() => setScreen('start')} />}
    </>
  );
}
