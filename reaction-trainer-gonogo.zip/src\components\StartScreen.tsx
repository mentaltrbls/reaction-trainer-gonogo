import { TOTAL_ATTEMPTS } from '../config';

interface StartScreenProps {
  onStart: () => void;
  onHistory: () => void;
}

export function StartScreen({ onStart, onHistory }: StartScreenProps) {
  return (
    <main className="screen">
      <button className="button ghost top-right" onClick={onHistory}>
        История
      </button>

      <h1>
        <span className="go">Go</span> / <span className="nogo">No-Go</span>
      </h1>
      <p className="subtitle">Тренажёр реакции на визуальные сигналы</p>

      <section className="rules">
        <p>
          <b>Go:</b> при зелёном сигнале нажмите пробел.
        </p>
        <p>
          <b>No-Go:</b> при красном сигнале ничего не нажимайте.
        </p>
        <p>
          <b>Важно:</b> нажатие до сигнала считается ошибкой.
        </p>
      </section>

      <button className="button primary" onClick={onStart}>
        Начать сессию
      </button>
      <p className="note">{TOTAL_ATTEMPTS} попыток, управление клавишей Space</p>
    </main>
  );
}
