export const TOTAL_ATTEMPTS = 20;
export const SIGNAL_DURATION_MS = 900;
export const NEXT_ATTEMPT_DELAY_MS = 600;
export const GO_PROBABILITY = 0.68;
export const MIN_SIGNAL_DELAY_MS = 700;
export const MAX_SIGNAL_DELAY_MS = 2200;
