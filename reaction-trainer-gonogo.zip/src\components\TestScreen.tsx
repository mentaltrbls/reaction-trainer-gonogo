import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  GO_PROBABILITY,
  MAX_SIGNAL_DELAY_MS,
  MIN_SIGNAL_DELAY_MS,
  NEXT_ATTEMPT_DELAY_MS,
  SIGNAL_DURATION_MS,
  TOTAL_ATTEMPTS
} from '../config';
import { Attempt, AttemptOutcome } from '../models/Attempt';
import { Signal, SignalType } from '../models/Signal';
import { SignalGenerator } from '../services/SignalGenerator';
import { StatisticsCalculator } from '../services/StatisticsCalculator';

type TestPhase = 'countdown' | 'waiting' | 'signal' | 'feedback';

interface TestScreenProps {
  onDone: (attempts: Attempt[]) => void;
}

export function TestScreen({ onDone }: TestScreenProps) {
  const generator = useMemo(
    () => new SignalGenerator(GO_PROBABILITY, MIN_SIGNAL_DELAY_MS, MAX_SIGNAL_DELAY_MS),
    []
  );

  const [phase, setPhase] = useState<TestPhase>('countdown');
  const [countdown, setCountdown] = useState(3);
  const [signal, setSignal] = useState<Signal | null>(null);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [message, setMessage] = useState('Приготовьтесь');

  const phaseRef = useRef<TestPhase>('countdown');
  const signalRef = useRef<Signal | null>(null);
  const attemptsRef = useRef<Attempt[]>([]);
  const timerRef = useRef<number | null>(null);

  const setPhaseSync = (nextPhase: TestPhase) => {
    phaseRef.current = nextPhase;
    setPhase(nextPhase);
  };

  const setSignalSync = (nextSignal: Signal | null) => {
    signalRef.current = nextSignal;
    setSignal(nextSignal);
  };

  const clearTimer = () => {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const addAttempt = useCallback((attempt: Attempt) => {
    attemptsRef.current = [...attemptsRef.current, attempt];
    setAttempts(attemptsRef.current);
  }, []);

  const finishAttemptLater = useCallback((startNextAttempt: () => void) => {
    setPhaseSync('feedback');
    timerRef.current = window.setTimeout(startNextAttempt, NEXT_ATTEMPT_DELAY_MS);
  }, []);

  const startNextAttempt = useCallback(() => {
    if (attemptsRef.current.length >= TOTAL_ATTEMPTS) {
      onDone(attemptsRef.current);
      return;
    }

    setPhaseSync('waiting');
    setSignalSync(null);
    setMessage('Ожидайте сигнал');

    timerRef.current = window.setTimeout(() => {
      const nextSignal = generator.nextSignal();
      setSignalSync(nextSignal);
      setPhaseSync('signal');
      setMessage(nextSignal.isGo ? 'Нажмите пробел' : 'Не нажимайте');

      timerRef.current = window.setTimeout(() => {
        if (phaseRef.current !== 'signal') {
          return;
        }

        if (signalRef.current?.type === SignalType.Go) {
          addAttempt(new Attempt(SignalType.Go, AttemptOutcome.Miss));
          setMessage('Пропуск');
        } else {
          addAttempt(new Attempt(SignalType.NoGo, AttemptOutcome.NoGoCorrect));
          setMessage('Верно');
        }

        finishAttemptLater(startNextAttempt);
      }, SIGNAL_DURATION_MS);
    }, generator.nextDelay());
  }, [addAttempt, finishAttemptLater, generator, onDone]);

  useEffect(() => {
    const countdownTimer = window.setInterval(() => {
      setCountdown((current) => {
        if (current <= 1) {
          window.clearInterval(countdownTimer);
          attemptsRef.current = [];
          setAttempts([]);
          startNextAttempt();
          return 0;
        }

        return current - 1;
      });
    }, 800);

    return () => {
      window.clearInterval(countdownTimer);
      clearTimer();
    };
  }, [startNextAttempt]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.code !== 'Space' || event.repeat) {
        return;
      }

      event.preventDefault();

      if (phaseRef.current === 'waiting') {
        clearTimer();
        addAttempt(new Attempt(null, AttemptOutcome.Early));
        setMessage('Слишком рано');
        finishAttemptLater(startNextAttempt);
        return;
      }

      if (phaseRef.current !== 'signal') {
        return;
      }

      clearTimer();

      if (signalRef.current?.type === SignalType.Go) {
        const reactionTime = Date.now() - signalRef.current.shownAt;
        addAttempt(new Attempt(SignalType.Go, AttemptOutcome.Success, reactionTime));
        setMessage(`${reactionTime} мс`);
      } else {
        addAttempt(new Attempt(SignalType.NoGo, AttemptOutcome.FalseAlarm));
        setMessage('Ложное нажатие');
      }

      finishAttemptLater(startNextAttempt);
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [addAttempt, finishAttemptLater, startNextAttempt]);

  const progress = (attempts.length / TOTAL_ATTEMPTS) * 100;
  const averageReactionTime = StatisticsCalculator.averageReactionTime(attempts);
  const signalClass = signal?.type === SignalType.Go ? 'go-signal' : 'nogo-signal';

  return (
    <main className="screen test-screen">
      {phase === 'countdown' && (
        <div className="countdown">
          <strong>{countdown}</strong>
          <span>Приготовьтесь</span>
        </div>
      )}

      <header className="test-header">
        <span>
          Попытка {Math.min(attempts.length + 1, TOTAL_ATTEMPTS)} / {TOTAL_ATTEMPTS}
        </span>
        <div className="progress">
          <div style={{ width: `${progress}%` }} />
        </div>
        <span>{averageReactionTime ? `${averageReactionTime} мс` : '-- мс'}</span>
      </header>

      <section className="signal-area">
        <div className={`signal ${phase === 'signal' ? signalClass : ''}`}>
          {phase === 'signal' ? signal?.type : '...'}
        </div>
        <p>{message}</p>
      </section>

      <footer className="test-footer">
        <span>Успешно: {StatisticsCalculator.successes(attempts)}</span>
        <span>Ошибки No-Go: {StatisticsCalculator.falseAlarms(attempts)}</span>
        <span>Пропуски: {StatisticsCalculator.misses(attempts)}</span>
      </footer>
    </main>
  );
}
