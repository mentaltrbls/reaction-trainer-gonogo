import { describe, expect, it } from 'vitest';
import { Attempt, AttemptOutcome } from '../models/Attempt';
import { SignalType } from '../models/Signal';
import { StatisticsCalculator } from './StatisticsCalculator';

describe('StatisticsCalculator', () => {
  const attempts = [
    new Attempt(SignalType.Go, AttemptOutcome.Success, 210),
    new Attempt(SignalType.Go, AttemptOutcome.Success, 290),
    new Attempt(SignalType.NoGo, AttemptOutcome.FalseAlarm),
    new Attempt(SignalType.Go, AttemptOutcome.Miss),
    new Attempt(null, AttemptOutcome.Early),
    new Attempt(SignalType.NoGo, AttemptOutcome.NoGoCorrect)
  ];

  it('calculates average reaction time only for successful Go attempts', () => {
    expect(StatisticsCalculator.averageReactionTime(attempts)).toBe(250);
  });

  it('counts false alarms', () => {
    expect(StatisticsCalculator.falseAlarms(attempts)).toBe(1);
  });

  it('counts misses', () => {
    expect(StatisticsCalculator.misses(attempts)).toBe(1);
  });

  it('counts successful reactions', () => {
    expect(StatisticsCalculator.successes(attempts)).toBe(2);
  });
});
